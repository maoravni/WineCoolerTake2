/*******************************************************************************
* File Name: PinGnd.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PinGnd_H) /* Pins PinGnd_H */
#define CY_PINS_PinGnd_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PinGnd_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PinGnd__PORT == 15 && ((PinGnd__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    PinGnd_Write(uint8 value);
void    PinGnd_SetDriveMode(uint8 mode);
uint8   PinGnd_ReadDataReg(void);
uint8   PinGnd_Read(void);
void    PinGnd_SetInterruptMode(uint16 position, uint16 mode);
uint8   PinGnd_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the PinGnd_SetDriveMode() function.
     *  @{
     */
        #define PinGnd_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define PinGnd_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define PinGnd_DM_RES_UP          PIN_DM_RES_UP
        #define PinGnd_DM_RES_DWN         PIN_DM_RES_DWN
        #define PinGnd_DM_OD_LO           PIN_DM_OD_LO
        #define PinGnd_DM_OD_HI           PIN_DM_OD_HI
        #define PinGnd_DM_STRONG          PIN_DM_STRONG
        #define PinGnd_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define PinGnd_MASK               PinGnd__MASK
#define PinGnd_SHIFT              PinGnd__SHIFT
#define PinGnd_WIDTH              1u

/* Interrupt constants */
#if defined(PinGnd__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PinGnd_SetInterruptMode() function.
     *  @{
     */
        #define PinGnd_INTR_NONE      (uint16)(0x0000u)
        #define PinGnd_INTR_RISING    (uint16)(0x0001u)
        #define PinGnd_INTR_FALLING   (uint16)(0x0002u)
        #define PinGnd_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define PinGnd_INTR_MASK      (0x01u) 
#endif /* (PinGnd__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PinGnd_PS                     (* (reg8 *) PinGnd__PS)
/* Data Register */
#define PinGnd_DR                     (* (reg8 *) PinGnd__DR)
/* Port Number */
#define PinGnd_PRT_NUM                (* (reg8 *) PinGnd__PRT) 
/* Connect to Analog Globals */                                                  
#define PinGnd_AG                     (* (reg8 *) PinGnd__AG)                       
/* Analog MUX bux enable */
#define PinGnd_AMUX                   (* (reg8 *) PinGnd__AMUX) 
/* Bidirectional Enable */                                                        
#define PinGnd_BIE                    (* (reg8 *) PinGnd__BIE)
/* Bit-mask for Aliased Register Access */
#define PinGnd_BIT_MASK               (* (reg8 *) PinGnd__BIT_MASK)
/* Bypass Enable */
#define PinGnd_BYP                    (* (reg8 *) PinGnd__BYP)
/* Port wide control signals */                                                   
#define PinGnd_CTL                    (* (reg8 *) PinGnd__CTL)
/* Drive Modes */
#define PinGnd_DM0                    (* (reg8 *) PinGnd__DM0) 
#define PinGnd_DM1                    (* (reg8 *) PinGnd__DM1)
#define PinGnd_DM2                    (* (reg8 *) PinGnd__DM2) 
/* Input Buffer Disable Override */
#define PinGnd_INP_DIS                (* (reg8 *) PinGnd__INP_DIS)
/* LCD Common or Segment Drive */
#define PinGnd_LCD_COM_SEG            (* (reg8 *) PinGnd__LCD_COM_SEG)
/* Enable Segment LCD */
#define PinGnd_LCD_EN                 (* (reg8 *) PinGnd__LCD_EN)
/* Slew Rate Control */
#define PinGnd_SLW                    (* (reg8 *) PinGnd__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PinGnd_PRTDSI__CAPS_SEL       (* (reg8 *) PinGnd__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PinGnd_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PinGnd__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PinGnd_PRTDSI__OE_SEL0        (* (reg8 *) PinGnd__PRTDSI__OE_SEL0) 
#define PinGnd_PRTDSI__OE_SEL1        (* (reg8 *) PinGnd__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PinGnd_PRTDSI__OUT_SEL0       (* (reg8 *) PinGnd__PRTDSI__OUT_SEL0) 
#define PinGnd_PRTDSI__OUT_SEL1       (* (reg8 *) PinGnd__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PinGnd_PRTDSI__SYNC_OUT       (* (reg8 *) PinGnd__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(PinGnd__SIO_CFG)
    #define PinGnd_SIO_HYST_EN        (* (reg8 *) PinGnd__SIO_HYST_EN)
    #define PinGnd_SIO_REG_HIFREQ     (* (reg8 *) PinGnd__SIO_REG_HIFREQ)
    #define PinGnd_SIO_CFG            (* (reg8 *) PinGnd__SIO_CFG)
    #define PinGnd_SIO_DIFF           (* (reg8 *) PinGnd__SIO_DIFF)
#endif /* (PinGnd__SIO_CFG) */

/* Interrupt Registers */
#if defined(PinGnd__INTSTAT)
    #define PinGnd_INTSTAT            (* (reg8 *) PinGnd__INTSTAT)
    #define PinGnd_SNAP               (* (reg8 *) PinGnd__SNAP)
    
	#define PinGnd_0_INTTYPE_REG 		(* (reg8 *) PinGnd__0__INTTYPE)
#endif /* (PinGnd__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PinGnd_H */


/* [] END OF FILE */
