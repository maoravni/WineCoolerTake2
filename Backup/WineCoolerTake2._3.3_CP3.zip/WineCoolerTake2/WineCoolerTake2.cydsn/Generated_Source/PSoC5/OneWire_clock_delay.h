/*******************************************************************************
* File Name: OneWire_clock_delay.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_OneWire_clock_delay_H)
#define CY_CLOCK_OneWire_clock_delay_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void OneWire_clock_delay_Start(void) ;
void OneWire_clock_delay_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void OneWire_clock_delay_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void OneWire_clock_delay_StandbyPower(uint8 state) ;
void OneWire_clock_delay_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 OneWire_clock_delay_GetDividerRegister(void) ;
void OneWire_clock_delay_SetModeRegister(uint8 modeBitMask) ;
void OneWire_clock_delay_ClearModeRegister(uint8 modeBitMask) ;
uint8 OneWire_clock_delay_GetModeRegister(void) ;
void OneWire_clock_delay_SetSourceRegister(uint8 clkSource) ;
uint8 OneWire_clock_delay_GetSourceRegister(void) ;
#if defined(OneWire_clock_delay__CFG3)
void OneWire_clock_delay_SetPhaseRegister(uint8 clkPhase) ;
uint8 OneWire_clock_delay_GetPhaseRegister(void) ;
#endif /* defined(OneWire_clock_delay__CFG3) */

#define OneWire_clock_delay_Enable()                       OneWire_clock_delay_Start()
#define OneWire_clock_delay_Disable()                      OneWire_clock_delay_Stop()
#define OneWire_clock_delay_SetDivider(clkDivider)         OneWire_clock_delay_SetDividerRegister(clkDivider, 1u)
#define OneWire_clock_delay_SetDividerValue(clkDivider)    OneWire_clock_delay_SetDividerRegister((clkDivider) - 1u, 1u)
#define OneWire_clock_delay_SetMode(clkMode)               OneWire_clock_delay_SetModeRegister(clkMode)
#define OneWire_clock_delay_SetSource(clkSource)           OneWire_clock_delay_SetSourceRegister(clkSource)
#if defined(OneWire_clock_delay__CFG3)
#define OneWire_clock_delay_SetPhase(clkPhase)             OneWire_clock_delay_SetPhaseRegister(clkPhase)
#define OneWire_clock_delay_SetPhaseValue(clkPhase)        OneWire_clock_delay_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(OneWire_clock_delay__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define OneWire_clock_delay_CLKEN              (* (reg8 *) OneWire_clock_delay__PM_ACT_CFG)
#define OneWire_clock_delay_CLKEN_PTR          ((reg8 *) OneWire_clock_delay__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define OneWire_clock_delay_CLKSTBY            (* (reg8 *) OneWire_clock_delay__PM_STBY_CFG)
#define OneWire_clock_delay_CLKSTBY_PTR        ((reg8 *) OneWire_clock_delay__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define OneWire_clock_delay_DIV_LSB            (* (reg8 *) OneWire_clock_delay__CFG0)
#define OneWire_clock_delay_DIV_LSB_PTR        ((reg8 *) OneWire_clock_delay__CFG0)
#define OneWire_clock_delay_DIV_PTR            ((reg16 *) OneWire_clock_delay__CFG0)

/* Clock MSB divider configuration register. */
#define OneWire_clock_delay_DIV_MSB            (* (reg8 *) OneWire_clock_delay__CFG1)
#define OneWire_clock_delay_DIV_MSB_PTR        ((reg8 *) OneWire_clock_delay__CFG1)

/* Mode and source configuration register */
#define OneWire_clock_delay_MOD_SRC            (* (reg8 *) OneWire_clock_delay__CFG2)
#define OneWire_clock_delay_MOD_SRC_PTR        ((reg8 *) OneWire_clock_delay__CFG2)

#if defined(OneWire_clock_delay__CFG3)
/* Analog clock phase configuration register */
#define OneWire_clock_delay_PHASE              (* (reg8 *) OneWire_clock_delay__CFG3)
#define OneWire_clock_delay_PHASE_PTR          ((reg8 *) OneWire_clock_delay__CFG3)
#endif /* defined(OneWire_clock_delay__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define OneWire_clock_delay_CLKEN_MASK         OneWire_clock_delay__PM_ACT_MSK
#define OneWire_clock_delay_CLKSTBY_MASK       OneWire_clock_delay__PM_STBY_MSK

/* CFG2 field masks */
#define OneWire_clock_delay_SRC_SEL_MSK        OneWire_clock_delay__CFG2_SRC_SEL_MASK
#define OneWire_clock_delay_MODE_MASK          (~(OneWire_clock_delay_SRC_SEL_MSK))

#if defined(OneWire_clock_delay__CFG3)
/* CFG3 phase mask */
#define OneWire_clock_delay_PHASE_MASK         OneWire_clock_delay__CFG3_PHASE_DLY_MASK
#endif /* defined(OneWire_clock_delay__CFG3) */

#endif /* CY_CLOCK_OneWire_clock_delay_H */


/* [] END OF FILE */
